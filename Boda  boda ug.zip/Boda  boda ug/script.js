// Show today's special offer
function showOffer() {
  alert("Today's Offer: 20% discount on Kampala city rides!");
}

// Confirm booking form submission
function confirmBooking() {
  const pickup = document.querySelector("input[name='pickup']").value;
  const destination = document.querySelector("input[name='destination']").value;
  const time = document.querySelector("input[name='time']").value;

  if (pickup && destination && time) {
    alert(`Booking confirmed!\nPickup: ${pickup}\nDestination: ${destination}\nTime: ${time}`);
    return false; // Prevents actual form submission for demo
  } else {
    alert("Please fill in all booking details.");
    return false;
  }
}

// Contact form submission
function sendMessage() {
  const name = document.querySelector("input[name='name']").value;
  const email = document.querySelector("input[name='email']").value;
  const message = document.querySelector("textarea[name='message']").value;

  if (name && email && message) {
    alert(`Thank you ${name}! Your message has been sent.`);
    return false;
  } else {
    alert("Please complete all fields before sending.");
    return false;
  }
}
